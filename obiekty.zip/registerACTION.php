<?php

if (isset($_POST['name']) && !empty($_POST['name'])) {
  $name = $_POST['name'];
//var_dump($name);
} else {
  echo "Enter your name";
  die();
}
if (isset($_POST['surname']) && !empty($_POST['surname'])) {
  $surname = $_POST['surname'];
} else {
  echo "Enter your surname";
  die();
}
if (isset($_POST['email']) && !empty($_POST['email'])) {
  $email = $_POST['email'];
} else {
  echo "Enter your email";
  die();
}
if (isset($_POST['password']) && !empty($_POST['password'])) {
  $password = $_POST['password'];
} else {
  echo "Enter your password";
  die();
}
if (isset($_POST['repassword']) && !empty($_POST['repassword'])) {
  $repassword = $_POST['repassword'];
  if ($password != $repassword) {
    echo "Repeat your password";
  }
} else {
  echo "Enter your password";
  die();
}

$dataUser = [
  'name' => $name,
  'surname' => $surname,
  'email' => $email,
  'password' => md5($password)
];
$dataUserSer = serialize($dataUser);
//var_dump($dataUserSer);
$userName = md5($email);
//var_dump($userName);
  if (!file_exists('regUsers/')) {
    mkdir('regUsers/');
    echo "Folder created.<br>";
  }

if (file_exists('regUsers/'.$userName)) {
  echo "User exists and will be overwritten.";
}

file_put_contents('regUsers/'.$userName, $dataUserSer);
echo "User registred as <b>{$userName}<b>.<br>";
 ?>
<html>
<a href="loginFORM.php">LOGOWANIE</a>
</html>
