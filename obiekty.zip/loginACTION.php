<?php
session_start();

if (isset($_POST['email']) && !empty($_POST['email'])) {
  $email = $_POST['email'];
} else {
  echo "Enter your email";
  die();
}
if (isset($_POST['password']) && !empty($_POST['password'])) {
  $password = $_POST['password'];
} else {
  echo "Enter your password";
  die();
}

$filename = md5($email);
//var_dump($userName);
if (!file_exists('regUsers/')) {
    echo 'Folder does not exist, will be created.';
    mkdir('regUsers');
}
if (file_exists('regUsers/'. $filename)) {
  $userReg = file_get_contents('regUsers/'. $filename);

} else {
  echo "User not registered.";

  die();
}

$unser = unserialize($userReg);
// tutaj mamy pełne dane usera

if (md5($password) != $unser['password']) {
  echo 'Spadaj!!';

  // "wylogowanie" użytownika - wyczyszczenie jego danych z sesji
  unset($_SESSION['userData']);

  die();
}

// zalogowanie usera:
$_SESSION['userData'] = $unser;

header('Location: dashboard.php');
