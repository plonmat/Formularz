<html>
  <head>
      <title>LOGIN</title>
      <meta charset=UTF-8>
  </head>
  <body>
      <p>LOGIN FORM</P>
        <form method="POST" action="loginACTION.php">
          <table>
            <tr><td>Email</td><td><input type="email" name="email"></td></tr>
            <tr><td>Password</td><td><input type="password" name="password"></td></tr>
            <tr><td><input type="submit"></td><td><input type="reset"></td></tr>
          </table>

          <a href="register.php">Powrót do rejestracji</a>

  </body>
</html>
