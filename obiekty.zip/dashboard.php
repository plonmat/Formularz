<?php
session_start();

if(!isset($_SESSION['userData'])){
  echo "User unlogged!";
  die();
}
//var_dump($_SESSION);
$user = $_SESSION['userData'];


echo 'Witaj '. $user['name']. ' '. $user['surname']. '!!';
